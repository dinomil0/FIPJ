import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab-market-history',
  templateUrl: './tab-market-history.page.html',
  styleUrls: ['./tab-market-history.page.scss'],
})
export class TabMarketHistoryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
