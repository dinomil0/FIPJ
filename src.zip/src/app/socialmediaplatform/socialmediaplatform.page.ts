import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-socialmediaplatform',
  templateUrl: './socialmediaplatform.page.html',
  styleUrls: ['./socialmediaplatform.page.scss'],
})
export class SocialmediaplatformPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
