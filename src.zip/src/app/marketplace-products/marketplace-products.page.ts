import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marketplace-products',
  templateUrl: './marketplace-products.page.html',
  styleUrls: ['./marketplace-products.page.scss'],
})
export class MarketplaceProductsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
