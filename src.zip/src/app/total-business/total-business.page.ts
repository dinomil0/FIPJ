import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-total-business',
  templateUrl: './total-business.page.html',
  styleUrls: ['./total-business.page.scss'],
})
export class TotalBusinessPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
