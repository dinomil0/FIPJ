export class Acra {
    id: number;
   name: string;
   uen: string;
}
