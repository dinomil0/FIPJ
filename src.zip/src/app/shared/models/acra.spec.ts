import { Acra } from './acra';

describe('Acra', () => {
  it('should create an instance', () => {
    expect(new Acra()).toBeTruthy();
  });
});
