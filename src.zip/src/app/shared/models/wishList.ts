export class wishList {

    constructor(
      public productID: string[] = [],
      public id?: string
      ) { }
  
  }