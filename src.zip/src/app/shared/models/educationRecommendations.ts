export class EducationRecommendations {

    constructor(
      public tags: [],
      public id?: string
      ) { }
  
  }