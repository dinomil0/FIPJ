export class beansHistory {

    constructor(
      public title: string,
      public description: string,
      public date: Date,
      public numberofbeans: number,
      public add: boolean,
      public minus: boolean,
      public image: string,
      public id?: string,   
      ) { }
  
  }