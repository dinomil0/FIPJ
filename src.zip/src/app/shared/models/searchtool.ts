export class Searchtool {
    constructor(
      public name: string,
      public notified: boolean,
      public userNotified: boolean,
      public productID: string,
      public id?: string
      ) { }
  
  }