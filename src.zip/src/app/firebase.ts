import { config } from "rxjs";

const firebaseConfig = {
    apiKey: "AIzaSyDoBcxru4JwgU7_tVkoLVRk0aXnG5oSjQA",
    authDomain: "fypj-5cf75.firebaseapp.com",
    projectId: "fypj-5cf75",
    storageBucket: "fypj-5cf75.appspot.com",
    messagingSenderId: "99501682607",
    appId: "1:99501682607:web:2f4df7ea8b81f7f4b8895a",
    measurementId: "G-2HWQVKPJB0"
};

export default config;