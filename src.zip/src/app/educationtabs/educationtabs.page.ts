import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-educationtabs',
  templateUrl: './educationtabs.page.html',
  styleUrls: ['./educationtabs.page.scss'],
})
export class EducationtabsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
